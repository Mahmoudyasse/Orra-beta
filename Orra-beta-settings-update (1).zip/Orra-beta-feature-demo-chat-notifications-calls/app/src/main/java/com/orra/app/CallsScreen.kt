package com.orra.app

import androidx.compose.material.icons.filled.Videocam
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import android.Manifest
import android.content.pm.PackageManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.layout.height
import androidx.compose.ui.window.Dialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.text.DateFormat
import androidx.compose.material3.Button
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Date

@Composable
fun CallsScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var callActionError by remember { mutableStateOf("") }
    var entries by remember { mutableStateOf(readOrraCallHistory(context)) }
    val prefs = remember { context.getSharedPreferences(SupabaseChatClient.PREFS, android.content.Context.MODE_PRIVATE) }
    val userId = prefs.getString("user_id", "").orEmpty()
    val accessToken = prefs.getString("token", "").orEmpty()
    var query by remember { mutableStateOf("") }
    var directionFilter by remember { mutableStateOf("All") }
    var showClearDialog by remember { mutableStateOf(false) }
    var pickerType by remember { mutableStateOf<String?>(null) }
    var people by remember { mutableStateOf<List<OrraChatConversation>>(emptyList()) }
    val startCall = rememberOrraCallAction()
    val filteredEntries = remember(entries, query) {
        entries.filter { entry ->
            (directionFilter == "All" || entry.direction.equals(directionFilter, ignoreCase = true)) &&
                (query.isBlank() || entry.name.contains(query, ignoreCase = true) || entry.number.contains(query, ignoreCase = true))
        }
    }

    LaunchedEffect(Unit) {
        entries = readOrraCallHistory(context)
    }
    LaunchedEffect(pickerType) {
        if (pickerType != null) {
            people = runCatching { withContext(Dispatchers.IO) { orraClient(context)?.loadConversations().orEmpty() } }
                .getOrDefault(emptyList()).filter { !it.isGroup && !it.isAi && !it.peerUserId.isNullOrBlank() }
        }
    }
    fun startInternetCall(person: OrraChatConversation, type: String) {
        val peerId = person.peerUserId.orEmpty()
        if (!OrraNet.isOnline(context)) { callActionError = tr("no_internet"); return }
        callActionError = ""
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) { OrraCallSignaling(context, userId, accessToken).createCall(peerId, type) }
            }
            result.onSuccess { call ->
                OrraInternetCallState.begin(call, person.username, true, userId, accessToken)
                recordOrraInternetCall(context, person.username, peerId, "Outgoing", type)
            }.onFailure { callActionError = if (!OrraNet.isOnline(context)) tr("no_internet") else (it.message ?: tr("calling_failed")) }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(start = 18.dp, end = 18.dp, top = 58.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr("s_b21c391f"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Incoming and outgoing calls handled by ORRA",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
            IconButton(onClick = { showClearDialog = true }, enabled = entries.isNotEmpty()) {
                Icon(Icons.Default.Delete, contentDescription = "Clear call history")
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { pickerType = "audio" }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Call, contentDescription = null); Text("  " + tr("voice_call"))
            }
            Button(onClick = { pickerType = "video" }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Videocam, contentDescription = null); Text("  " + tr("video_call"))
            }
        }
        if (callActionError.isNotBlank()) Text(callActionError, color = MaterialTheme.colorScheme.error)

        if (entries.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("All", "Incoming", "Outgoing").forEach { filter ->
                    if (directionFilter == filter) androidx.compose.material3.Button(onClick = { directionFilter = filter }) { Text(filter) }
                    else OutlinedButton(onClick = { directionFilter = filter }) { Text(filter) }
                }
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text(tr("s_bf9e347d")) }
            )
        }

        if (entries.isEmpty()) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(26.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.History, contentDescription = null)
                    Text(tr("s_2a4ab262"), fontWeight = FontWeight.Medium)
                    Text(
                        "Numbers opened from the ORRA keypad or contacts appear here. This is a local app history, not your phone's full call log.",
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        } else if (filteredEntries.isEmpty()) {
            Text(
                "No matching numbers",
                modifier = Modifier.fillMaxWidth().padding(24.dp),
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filteredEntries, key = { "${it.timestamp}-${it.number}" }) { entry ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(entry.name, fontWeight = FontWeight.Medium)
                            Text(if (entry.isInternet) "ORRA • ${if (entry.callType == "video") "Video" else "Voice"}" else entry.number, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                            Text(entry.direction, style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary)
                            Text(
                                DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                                    .format(Date(entry.timestamp)),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                            )
                        }
                        IconButton(onClick = {
                            if (entry.isInternet && !OrraNet.isOnline(context)) {
                                callActionError = tr("no_internet")
                            } else if (entry.isInternet && !entry.peerId.isNullOrBlank() && userId.isNotBlank() && accessToken.isNotBlank()) {
                                scope.launch {
                                    val result = runCatching {
                                        withContext(Dispatchers.IO) {
                                            OrraCallSignaling(context, userId, accessToken).createCall(entry.peerId!!, entry.callType)
                                        }
                                    }
                                    result.onSuccess { call ->
                                        OrraInternetCallState.begin(call, entry.name, true, userId, accessToken)
                                        recordOrraInternetCall(context, entry.name, entry.peerId!!, "Outgoing", entry.callType)
                                    }.onFailure { callActionError = it.message ?: "Could not start ORRA call." }
                                }
                            } else if (!entry.isInternet) startCall(entry.name, entry.number)
                        }) {
                            Icon(Icons.Default.Call, contentDescription = "Call ${entry.name}", tint = CallGreen)
                        }
                    }
                }
            }
        }
    }

    pickerType?.let { type ->
        AlertDialog(
            onDismissRequest = { pickerType = null },
            title = { Text(tr("pick_contact")) },
            text = {
                Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                    if (people.isEmpty()) Text(tr("no_contacts_call"))
                    people.forEach { person ->
                        TextButton(onClick = { pickerType = null; startInternetCall(person, type) }) { Text(person.username) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { pickerType = null }) { Text(tr("cancel")) } }
        )
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text(tr("s_f89ed43c")) },
            text = { Text(tr("s_927e1a8e")) },
            confirmButton = {
                TextButton(onClick = {
                    clearOrraCallHistory(context)
                    entries = emptyList()
                    showClearDialog = false
                }) { Text(tr("s_dc30bc0c")) }
            },
            dismissButton = {
                OutlinedButton(onClick = { showClearDialog = false }) { Text(tr("s_ea478870")) }
            }
        )
    }
}

